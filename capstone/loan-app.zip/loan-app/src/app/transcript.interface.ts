export interface ITranscript {
  course: string;
  grade: string;
}
